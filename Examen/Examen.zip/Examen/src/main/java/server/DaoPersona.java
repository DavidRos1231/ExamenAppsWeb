package server;


import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DaoPersona {
    public boolean registro(BeanPersona persona){
        boolean result=false;
        try{
            MySQLConnection connection=new MySQLConnection();
            connection.getConnection();
            PreparedStatement pstm=connection.getConnection().prepareStatement("INSERT INTO `examen`.`persona` (`CURP`, `nombre`, `apellido1`, `apellido2`, `anio`, `mes`, `dia`,`rfc`) VALUES (?, ?, ?, ?, ?, ?, ?,?);");
            pstm.setString(1,persona.getCurp());
            pstm.setString(2,persona.getName());
            pstm.setString(3,persona.getApellido1());
            pstm.setString(4,persona.getApellido2());
            pstm.setInt(5,persona.getAnio());
            pstm.setInt(6,persona.getMes());
            pstm.setInt(7,persona.getDia());
            pstm.setString(8,persona.getRfc());

            result=  (pstm.executeUpdate()==1);
            }
        catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    public String consulta( String curp){
        boolean result=false;
        String persona="";
        try{
            MySQLConnection connection=new MySQLConnection();
            connection.getConnection();
            PreparedStatement pstm=connection.getConnection().prepareStatement("SELECT * FROM examen.persona where CURP =?;");
            pstm.setString(1,curp);
            ResultSet rs= pstm.executeQuery();
            if (rs.next()){
                persona=rs.getString("CURP")+" "+rs.getString("nombre")+" "+rs.getString("apellido1")+" "+rs.getString("apellido2")+" "+rs.getString("anio")+" "+rs.getString("mes")+" "+rs.getString("dia");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return persona;
    }
}
