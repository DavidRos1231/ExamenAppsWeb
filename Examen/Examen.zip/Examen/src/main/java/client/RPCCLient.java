package client;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import server.BeanPersona;
import server.Methods;

import java.util.Map;
import java.util.Scanner;
import java.net.MalformedURLException;
import java.net.URL;

public class RPCCLient {
    public static void main(String[] args) throws XmlRpcException, MalformedURLException {
        Scanner entrada=new Scanner(System.in);
        XmlRpcClientConfigImpl config=new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client=new XmlRpcClient();
        client.setConfig(config);
        System.out.println("QUe desea hacer");
        System.out.println("1.-Registro");
        System.out.println("2.-Consulta por curp");
        int option= entrada.nextInt();
        entrada.nextLine();
        switch (option){
            case 1:
                System.out.println("Ingrese sus datos");
                System.out.println("Nombre");
                String nombre=entrada.nextLine();
                System.out.println("Primer apellido");
                String apellido1=entrada.nextLine();
                System.out.println("Segundo apellido");
                String apellido2=entrada.nextLine();
                System.out.println("Anio de nacimiento en numero");
                int ano=entrada.nextInt();
                System.out.println("Mes de nacimiento en numero");
                int mes= entrada.nextInt();
                System.out.println("dia de nacimiento en numero");
                int dia= entrada.nextInt();
                System.out.println("CURP");
                entrada.nextLine();
                String curp= entrada.nextLine();
                Object datos[]={nombre,apellido1,apellido2,ano,mes,dia,curp};
                System.out.println(client.execute("Methods.rfc",datos));
                break;
            case 2:
                System.out.println("Ingrese la CURP");
                String curp1= entrada.nextLine();
                Object objcurp[]={curp1};
                String persona;
                persona=client.execute("Methods.consulta",objcurp).toString();
                System.out.println(persona);
                break;
        }
    }
}
